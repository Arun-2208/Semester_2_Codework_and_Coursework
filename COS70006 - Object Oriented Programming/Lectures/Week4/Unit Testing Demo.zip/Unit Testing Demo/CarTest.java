

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CarTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CarTest
{
    /**
     * Default constructor for test class CarTest
     */
    private Car c;
    public CarTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        c = new Car();
        c.addPart(new Part("Engine",4000.99,"ENG001"));
        c.addPart(new Part("Doo2",200.99,"ENG001"));
        c.addPart(new Part("Head Light",99.99,"ENG001"));
        
    }
    
    @Test
    public void testNumberOfParts()
    {
        assertEquals(3, c.numberOfParts());
    }
    
    @Test
    public void testNumberOfPartsWrong()
    {
        assertEquals(2, c.numberOfParts());
    }
    
    @Test
    public void testPartsDescription()
    {
        assertEquals("Head Light", c.getPart(2).getDescription());
    }
    
    @Test
    public void exceptionThrown()
    {
        try{
            c.getPart(-99);
            fail("Fail, exception not thrown");
        }
        catch(Exception e){
        }
        //assertEquals("Head Light", c.getPart(2).getDescription());
    }
    
    @Test
    public void demonstrateFailedExceptionThrowing()
    {
        try{
            c.getPart(1);
            fail("Fail, exception not thrown");
        }
        catch(Exception e){
        }
        //assertEquals("Head Light", c.getPart(2).getDescription());
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
