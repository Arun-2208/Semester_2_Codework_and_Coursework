/**
 * This class is responsible to start the application.
 * 
 * @author Shamara Gibson
 * @version 1.0
 */ 
public class Start
{
    /**
     * The application starts execution from this method.
     * The console UserInterface is called from this method.
     * 
     */
    public static void main(String[] args)
    {
       
            Car c = new Car();
            UserInterface UI = new UserInterface(c);
            UI.run();    
           
         
    }
}// end start