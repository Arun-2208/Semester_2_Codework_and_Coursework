/**
 * Description
 * Author : Arun Ragavendhar Arunachalam Palaniyappan <104837257>
 * Lab : Week_1_lab
 */


 public class HelloWorld1{


    public static void main(String[] args){

        System.out.println(" How are you < Arun Ragavendhar > ?");
        
    }
 }