/**
 * This interface defines the resize abstract method to be implemented
 * @author : Arun Ragavendhar - 104837257
 * @date : lab9 - 1/10/2024
 */
interface Resizable{

// function definition to resize the radius 
     public void resize(int percent);

}